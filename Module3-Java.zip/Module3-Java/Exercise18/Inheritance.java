package Exercise18;

class Animal{
    void makeSound(){
        System.out.println("Animal makes a sound");
    }
}
class Dog extends Animal{
    @Override
    void makeSound(){
        System.out.println("Bark");
    }
}
public class Inheritance{
    public static void main(String[] args) {
        Animal a=new Animal();
        Dog d=new Dog();
        a.makeSound();
        d.makeSound();
    }
}

